package day16.ramda.basic;

//추상메서드가 1개인 인터페이스를 함수적 인터페이스 라고부름.
public interface Say01 {
	public void talking();
}
