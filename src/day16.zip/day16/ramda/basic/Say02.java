package day16.ramda.basic;

public interface Say02 {
	public String talking(String word);
}
