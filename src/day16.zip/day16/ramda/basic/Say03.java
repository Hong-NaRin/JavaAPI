package day16.ramda.basic;

public interface Say03 {
	public String calculating(int i, String word);
}
