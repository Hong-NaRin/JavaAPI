package day16.ramda.anonymous.basic;

public interface RemoteControl {

	public void volumeUp();
	public void volumeDown();
	public void turnOn();
	public void turnOff();
}