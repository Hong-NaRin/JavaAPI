package day16.ramda.anonymous.basic;

public class Tico implements Car {

	@Override
	public void run() {
		System.out.println("마이 티코");
	}
}