package day16.ramda.anonymous.basic;

public interface Car {
	public void run();
}